package lk.ijse.CABTEACK.modle;

import lk.ijse.CABTEACK.DB.DatabaseConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderController {
    public static List<String> getOrderAllIds() throws SQLException, ClassNotFoundException {
        ResultSet res= DatabaseConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehicleOrder").executeQuery();
        List<String> ids=new ArrayList<>();
        while (res.next()){
            ids.add(
                    res.getString(1)
            );

        }
        return  ids;
    }
    public static List<String> getOrderPartAllIds() throws SQLException, ClassNotFoundException {
        ResultSet res= DatabaseConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehiclePartsOrder").executeQuery();
        List<String> ids=new ArrayList<>();
        while (res.next()){
            ids.add(
                    res.getString(1)
            );

        }
        return  ids;
    }
    }

