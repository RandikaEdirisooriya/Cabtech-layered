package lk.ijse.CABTEACK;

public class
LauncherWrapper {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}
