package lk.ijse.CABTEACK.modle;

import lk.ijse.CABTEACK.DB.DatabaseConnection;
import lk.ijse.CABTEACK.modle.Dto.Customer;
import lk.ijse.CABTEACK.modle.Dto.VehicleParts;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VehiclePartsController {
    public static List<String> getVehicleIdsIds() throws SQLException, ClassNotFoundException {
        ResultSet res= DatabaseConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehicleparts").executeQuery();
        List<String> ids=new ArrayList<>();
        while (res.next()){
            ids.add(
                    res.getString(1)
            );

        }
        return  ids;
    }
public VehicleParts getVehicleParts(String id) throws SQLException, ClassNotFoundException {
    Connection con= DatabaseConnection.getInstance().getConnection();
    String sql = "SELECT * FROM vehicleparts WHERE partsId=?";
    PreparedStatement stm=con.prepareStatement(sql);
    stm.setObject(1,id);
    ResultSet res=stm.executeQuery();
    if(res.next()){
        VehicleParts v1=new VehicleParts(
                res.getString(1),
                res.getInt(2),
                res.getString(3),
                res.getString(4),
                res.getString(5),
                res.getString(6),
                res.getDouble(7)
        );
        return v1;
    }else{
        return null;
    }
}
    public boolean AddVehicleParts(VehicleParts c) throws SQLException, ClassNotFoundException {
        Connection con = DatabaseConnection.getInstance().getConnection();
        String sql = "INSERT INTO vehicleparts (partsId,qty,code,colour,description,nameOfVehiclePart,Price) VALUES (?,?,?,?,?,?,?)";

        PreparedStatement stm = con.prepareStatement(sql);
        stm.setString(1, c.getPartsId()); // Use setString to set the 'id'
        stm.setString(2, String.valueOf(c.getQty())); // Use setString to set the 'id'

        stm.setString(3, c.getCode());
        stm.setString(4, c.getColour());
        stm.setString(5, c.getDescription());
        stm.setString(6, c.getNameOfVehiclePart());
        stm.setString(7, String.valueOf(c.getPrice()));


        return stm.executeUpdate() > 0;
    }
    public int getAllItem() throws SQLException, ClassNotFoundException {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        String sql="SELECT COUNT(partsId) as partsId FROM vehicleParts";
        PreparedStatement pstm=connection.prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        int partId=0;
        while (resultSet.next()){
            partId=resultSet.getInt("partsId");
        }
        return partId;
    }
}
