package lk.ijse.CABTEACK.modle;

import javafx.scene.control.Alert;
import lk.ijse.CABTEACK.DB.DatabaseConnection;
import lk.ijse.CABTEACK.modle.Dto.*;
import lk.ijse.CABTEACK.util.CrudUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class vehicleController {
    public static List<String> getVehicleIds() throws SQLException, ClassNotFoundException {
        ResultSet res= DatabaseConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehicle WHERE vehicleType = 'car'").executeQuery();
        List<String> ids=new ArrayList<>();
        while (res.next()){
            ids.add(
                    res.getString(1)
            );

        }
        return  ids;
    }
    public static List<String> getVehicleTIds() throws SQLException, ClassNotFoundException {
        ResultSet res= DatabaseConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehicle WHERE vehicleType = 'Three Wheel'").executeQuery();
        List<String> ids=new ArrayList<>();
        while (res.next()){
            ids.add(
                    res.getString(1)
            );

        }
        return  ids;
    }
    public static List<String> getVehicleBIds() throws SQLException, ClassNotFoundException {
        ResultSet res= DatabaseConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehicle WHERE vehicleType = 'Bike'").executeQuery();
        List<String> ids=new ArrayList<>();
        while (res.next()){
            ids.add(
                    res.getString(1)
            );

        }
        return  ids;
    }
    public static List<String> getVehicleAllIds() throws SQLException, ClassNotFoundException {
        ResultSet res= DatabaseConnection.getInstance().getConnection().prepareStatement("SELECT * FROM vehicle").executeQuery();
        List<String> ids=new ArrayList<>();
        while (res.next()){
            ids.add(
                    res.getString(1)
            );

        }
        return  ids;
    }

    public boolean AddVehicle(vehicle v1) throws SQLException, ClassNotFoundException {
        Connection con = DatabaseConnection.getInstance().getConnection();
        String sql = "INSERT INTO vehicle (vehicleId,qty,vehicleType,nameOfVehicle,colour,price) VALUES (?,?,?,?,?,?)";

        PreparedStatement stm = con.prepareStatement(sql);
        stm.setString(1, v1.getVehicleId()); // Use setString to set the 'id'
        stm.setInt(2, v1.getQty());
        stm.setString(3, v1.getVehicleType());
        stm.setString(4, v1.getNameOfVehicle());
        stm.setString(5, v1.getColour());
        stm.setDouble(6, v1.getPrice());

        return stm.executeUpdate() > 0;
    }

    public vehicle getVehicleCar(String id) throws SQLException, ClassNotFoundException {
        Connection con = DatabaseConnection.getInstance().getConnection();
      String sql = "SELECT * FROM vehicle WHERE vehicleId =?";

        PreparedStatement stm = con.prepareStatement(sql);
        stm.setObject(1, id);
//            String sql = "SELECT * FROM customer WHERE id='"+id+"'";
        ResultSet Res = stm.executeQuery();
        if (Res.next()) {

            vehicle v1 = new vehicle(
                    Res.getString(1),
                    Res.getString(2),
                    Res.getString(3),
                    Res.getString(4),
                    Res.getDouble(5),
                    Res.getInt(6)

            );


            return v1;
        } else {
            return null;
        }

    }
public boolean updateVehicle(vehicle v1) throws SQLException, ClassNotFoundException {

    Connection con= DatabaseConnection.getInstance().getConnection();
    String sql="UPDATE vehicle SET qty=?,vehicleType=?,nameOfVehicle=?,colour=? ,price=? WHERE vehicleId=?";
    PreparedStatement stm=con.prepareStatement(sql);
    stm.setInt(1,v1.getQty());
    stm.setString(2,v1.getVehicleType());
    stm.setString(3, v1.getNameOfVehicle());
    stm.setString(4, v1.getColour());
    stm.setDouble(5, v1.getPrice());
    stm.setString(6,v1.getVehicleId());
    return stm.executeUpdate()>0;
}

    public boolean placeOrder(vehicleOrder order) throws SQLException, ClassNotFoundException {
        Connection connection = null;
        boolean success = false;

        try {
            connection = DatabaseConnection.getInstance().getConnection();
            connection.setAutoCommit(false);

            boolean isOrderInserted = CrudUtil.execute("INSERT INTO vehicleorder (vehicleOrderId,orderDate,orderTime,cost,customerId) " +
                    "VALUES (?,?,?,?,?)",order.getVehicleOrderId(),order.getOrderDate(),order.getOrderTime(),order.getCost(),order.getCustomerId());



            if (isOrderInserted) {
                if (saveOrderDetail(order.getVehicleOrderId(), order.getDetails(), connection)) {
                    success = true;
                }
            }

            if (success) {
                connection.commit();
              //  new Alert(Alert.AlertType.CONFIRMATION, "Done").show();
            } else {
                connection.rollback();
                new Alert(Alert.AlertType.WARNING, "Not Done").show();
            }
        } catch (SQLException e) {
            connection.rollback();
            throw e; // Re-throw the exception after rolling back the transaction
        } finally {
            if (connection != null) {
                connection.setAutoCommit(true);

            }
        }

        return success;
    }

    private boolean saveOrderDetail(String partOrderId, ArrayList<VehicleOrderDetails> items, Connection connection) {
        for (VehicleOrderDetails temp : items) {
            String detailSql = "INSERT INTO vehicleorderdetails (vehicleOrderId,vehicleId, qtyForSale, Price) VALUES (?,?,?,?)";

            try (PreparedStatement detailStm = connection.prepareStatement(detailSql)) {
                detailStm.setObject(1, partOrderId);
                detailStm.setObject(2, temp.getVehicleId());
                detailStm.setObject(3, temp.getQtyForSale());
                detailStm.setObject(4, temp.getAmount());

                if (detailStm.executeUpdate() <= 0) {
                    return false;
                }

                if (!updateQty(temp.getVehicleId(), temp.getQtyForSale(), connection)) {
                    return false;
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

        return true;
    }

    private boolean updateQty(String partId, int qtyForSale, Connection connection) {
        String updateSql = "UPDATE vehicle SET qty = qty - ? WHERE vehicleId = ?";

        try (PreparedStatement updateStm = connection.prepareStatement(updateSql)) {
            updateStm.setInt(1, qtyForSale);
            updateStm.setString(2, partId);


            int affectedRows = updateStm.executeUpdate();

            return affectedRows > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}