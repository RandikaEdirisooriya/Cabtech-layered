package lk.ijse.CABTEACK.modle;

import lk.ijse.CABTEACK.DB.DatabaseConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class adminController {

    public static List<String> getUserIds() throws SQLException, ClassNotFoundException {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        ResultSet resultSet = connection.prepareStatement("SELECT adminId FROM admin").executeQuery();

        List<String> ids = new ArrayList<>();
        while (resultSet.next()) {
            ids.add(resultSet.getString("adminId"));
        }
        return ids;
    }
}
