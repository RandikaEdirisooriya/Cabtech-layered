package lk.ijse.CABTEACK.modle;

import lk.ijse.CABTEACK.DB.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeController {
    public int getAllEmployee() throws SQLException, ClassNotFoundException {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        String sql="SELECT COUNT(EmpId) as EmpId FROM employee";
        PreparedStatement pstm=connection.prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        int empId=0;
        while (resultSet.next()){
            empId=resultSet.getInt("EmpId");
        }
        return empId;
    }
    public static List<String> getEmployeeIds() throws SQLException, ClassNotFoundException {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        ResultSet resultSet = connection.prepareStatement("SELECT EmpId FROM employee").executeQuery();

        List<String> ids = new ArrayList<>();
        while (resultSet.next()) {
            ids.add(resultSet.getString("EmpId"));
        }
        return ids;
    }
}
