package lk.ijse.CABTEACK.Controller;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import lk.ijse.CABTEACK.DB.DatabaseConnection;
import lk.ijse.CABTEACK.modle.adminController;
import org.controlsfx.control.Notifications;
import org.controlsfx.control.textfield.TextFields;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class ProfileFormController {

    @FXML
    private JFXTextField emailTxt;

    @FXML
    private JFXTextField fullnametxt;

    @FXML
    private JFXPasswordField passwordtxt;

    @FXML
    private JFXTextField userIdTxt;
    @FXML
    public void initialize() throws SQLException, ClassNotFoundException {
        loadAdminId();
    }

    private void loadAdminId() throws SQLException, ClassNotFoundException {
        List<String> cusI = adminController.getUserIds();
        TextFields.bindAutoCompletion(userIdTxt,cusI);
    }


    @FXML
    void createAccountOnAction(ActionEvent event) throws SQLException, ClassNotFoundException {
        String fullName = fullnametxt.getText();
        String userId = userIdTxt.getText();
        String password = passwordtxt.getText();
        String email = emailTxt.getText();

        // Validation using regex
        if (!fullName.isBlank() && !userId.isBlank() && !password.isBlank() && !email.isBlank()) {
            // Validate email format
            if (!email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
                ImageView imageView = new ImageView(new Image("/Asset/icons8-close-100.png"));
                Notifications.create()
                        .graphic(imageView)
                        .text(" Invalid email format. Please enter a valid email. ")
                        .title("WARNING")
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.TOP_RIGHT)
                        .darkStyle()
                        .show();
                //new Alert(Alert.AlertType.WARNING, "Invalid email format. Please enter a valid email.").show();
                return;
            }

            // Validate password format (at least 8 characters, at least one uppercase letter, one lowercase letter, and one digit)
            if (!password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$")) {
                ImageView imageView = new ImageView(new Image("/Asset/icons8-close-100.png"));
                Notifications.create()
                        .graphic(imageView)
                        .text("Invalid password format. Password must have at least 8 characters, one uppercase letter, one lowercase letter, and one digit. ")
                        .title("WARNING")
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.TOP_RIGHT)
                        .darkStyle()
                        .show();
               // new Alert(Alert.AlertType.WARNING, "Invalid password format. Password must have at least 8 characters, one uppercase letter, one lowercase letter, and one digit.").show();
                return;
            }

            // Proceed with inserting the data into the database
            Connection connection = DatabaseConnection.getInstance().getConnection();
            String sql = "INSERT INTO admin VALUES (?,?,?,?)";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(2, fullName);
            stm.setString(1, userId);
            stm.setString(3, password);
            stm.setString(4, email);
            int res = stm.executeUpdate();

            if (res > 0) {
                new Alert(Alert.AlertType.CONFIRMATION, "Created a user!!").show();
                fullnametxt.setText("");
                userIdTxt.setText("");
                passwordtxt.setText("");
                emailTxt.setText("");
            } else {
                ImageView imageView = new ImageView(new Image("/Asset/icons8-close-100.png"));
                Notifications.create()
                        .graphic(imageView)
                        .text(" Failed to create a user. Please try again. ")
                        .title("WARNING")
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.TOP_RIGHT)
                        .darkStyle()
                        .show();

             //   new Alert(Alert.AlertType.WARNING, "Failed to create a user. Please try again.").show();
            }
        } else {
            ImageView imageView = new ImageView(new Image("/Asset/icons8-close-100.png"));
            Notifications.create()
                    .graphic(imageView)
                    .text(" Not created a user. Something is missing.. ")
                    .title("WARNING")
                    .hideAfter(Duration.seconds(5))
                    .position(Pos.TOP_RIGHT)
                    .darkStyle()
                    .show();
           // new Alert(Alert.AlertType.WARNING, "Not created a user. Something is missing.").show();
        }
    }
}