package lk.ijse.CABTEACK.modle;

import lk.ijse.CABTEACK.DB.DatabaseConnection;
import lk.ijse.CABTEACK.modle.Dto.Customer;
import lk.ijse.CABTEACK.modle.Dto.vehicle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerController {
    public static List<String> getCustomerIds() throws SQLException, ClassNotFoundException {
        Connection connection = DatabaseConnection.getInstance().getConnection();
        ResultSet resultSet = connection.prepareStatement("SELECT customerId FROM customer").executeQuery();

        List<String> ids = new ArrayList<>();
        while (resultSet.next()) {
            ids.add(resultSet.getString("customerId"));
        }
        return ids;
    }

    public boolean AddCustomer(Customer c) throws SQLException, ClassNotFoundException {
        Connection con = DatabaseConnection.getInstance().getConnection();
        String sql = "INSERT INTO customer (customerId,name,address,nic_number,contactNumber) VALUES (?,?,?,?,?)";

        PreparedStatement stm = con.prepareStatement(sql);
        stm.setString(1, c.getCustomerId()); // Use setString to set the 'id'
        stm.setString(2, c.getName()); // Use setString to set the 'id'

        stm.setString(3, c.getAddress());
        stm.setString(4, c.getNic_number());
        stm.setString(5, c.getContactNumber());


        return stm.executeUpdate() > 0;
    }
}